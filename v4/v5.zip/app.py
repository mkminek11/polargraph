"""
Flask backend for the polargraph: ONE Arduino drives both stepper motors
over a single serial (COM) port. Every move sends both motors' absolute
step targets in one line:

    GOTO <leftSteps> <rightSteps>

See motion_control.py for how a target (x, y) becomes those two step
counts, and for why they're absolute targets rather than relative deltas.
"""

import threading
import time

import serial
import serial.tools.list_ports
from flask import Flask, jsonify, request, send_from_directory

import motion_control as motion

app = Flask(__name__, static_folder=".", static_url_path="")

MAX_LOG_LINES = 200
SMILEY_POINT_DELAY_SECONDS = 0.05  # pacing between queued moves; replace with a real ACK handshake once firmware exists

# Opening a serial port resets most Arduino boards (DTR toggles reset),
# which takes a couple seconds to reboot and print "READY". Wait this long
# before syncing position, or the SET command gets lost during the reboot.
ARDUINO_BOOT_DELAY_SECONDS = 2.5

serial_lock = threading.Lock()
motion_lock = threading.Lock()
busy = {"value": False}
log = []

state = {"connection": None, "port": None, "baudrate": 115200}


def _append_log(text):
    log.append({"text": text, "time": time.time()})
    if len(log) > MAX_LOG_LINES:
        del log[: len(log) - MAX_LOG_LINES]


def _reader_loop(ser):
    """Background thread: streams anything the Arduino sends back into the log."""
    while True:
        with serial_lock:
            if state["connection"] is not ser:
                return
        try:
            line = ser.readline()
        except Exception:
            return
        if line:
            text = line.decode("utf-8", errors="replace").strip()
            if text:
                _append_log(f"recv: {text}")


def _send_steps(left_steps, right_steps):
    with serial_lock:
        ser = state["connection"]
        if ser is None or not ser.is_open:
            return False, "Not connected"
        try:
            ser.write(f"GOTO {left_steps} {right_steps}\n".encode("utf-8"))
        except Exception as e:
            return False, str(e)
    _append_log(f"GOTO {left_steps} {right_steps}")
    return True, None


def _send_sync(left_steps, right_steps):
    with serial_lock:
        ser = state["connection"]
        if ser is None or not ser.is_open:
            return False, "Not connected"
        try:
            ser.write(f"SET {left_steps} {right_steps}\n".encode("utf-8"))
        except Exception as e:
            return False, str(e)
    _append_log(f"SET {left_steps} {right_steps}")
    return True, None


motion.configure(_send_steps, _send_sync)


def _sync_after_connect():
    """Waits out the Arduino's post-connect reboot, then tells it where the
    Pi already thinks the gondola is -- see motion_control.sync_position().
    Holds motion_lock for the whole wait so a jog/move can't sneak in and
    race the sync (which would still see the huge false-zero catch-up)."""
    if not motion_lock.acquire(blocking=True, timeout=ARDUINO_BOOT_DELAY_SECONDS + 5):
        return
    try:
        busy["value"] = True
        time.sleep(ARDUINO_BOOT_DELAY_SECONDS)
        ok, error = motion.sync_position()
        _append_log("Synced position after connect" if ok else f"Position sync failed: {error}")
    finally:
        busy["value"] = False
        motion_lock.release()


def _run_locked(fn, *args):
    if not motion_lock.acquire(blocking=False):
        return False, "Machine is busy", None
    try:
        busy["value"] = True
        result = fn(*args)
        return True, None, result
    except motion.MotionError as e:
        return False, str(e), None
    finally:
        busy["value"] = False
        motion_lock.release()


@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/api/ports")
def list_ports():
    ports = serial.tools.list_ports.comports()
    return jsonify([{"device": p.device, "description": p.description} for p in ports])


@app.route("/api/status")
def status():
    with serial_lock:
        connected = state["connection"] is not None and state["connection"].is_open
        return jsonify(
            {
                "connected": connected,
                "port": state["port"],
                "baudrate": state["baudrate"],
                "busy": busy["value"],
            }
        )


@app.route("/api/position")
def position():
    x, y = motion.state.position
    return jsonify({"x": x, "y": y})


@app.route("/api/connect", methods=["POST"])
def connect():
    data = request.get_json(force=True) or {}
    port = data.get("port")
    baudrate = int(data.get("baudrate", 115200))
    if not port:
        return jsonify({"ok": False, "error": "No port specified"}), 400

    with serial_lock:
        if state["connection"] is not None:
            try:
                state["connection"].close()
            except Exception:
                pass
            state["connection"] = None

        try:
            ser = serial.Serial(port, baudrate, timeout=1)
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

        state["connection"] = ser
        state["port"] = port
        state["baudrate"] = baudrate

    threading.Thread(target=_reader_loop, args=(ser,), daemon=True).start()
    _append_log(f"Connected to {port} @ {baudrate}")
    threading.Thread(target=_sync_after_connect, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/disconnect", methods=["POST"])
def disconnect():
    with serial_lock:
        if state["connection"] is not None:
            try:
                state["connection"].close()
            except Exception:
                pass
            state["connection"] = None
            state["port"] = None
    _append_log("Disconnected")
    return jsonify({"ok": True})


@app.route("/api/jog", methods=["POST"])
def jog():
    data = request.get_json(force=True) or {}
    dx, dy = float(data.get("dx", 0)), float(data.get("dy", 0))
    ok, error, result = _run_locked(motion.jog, dx, dy)
    if not ok:
        return jsonify({"ok": False, "error": error}), 409 if error == "Machine is busy" else 400
    return jsonify({"ok": True, "position": result})


@app.route("/api/move", methods=["POST"])
def move():
    data = request.get_json(force=True) or {}
    x, y = data.get("x"), data.get("y")
    if x is None or y is None:
        return jsonify({"ok": False, "error": "x and y required"}), 400
    ok, error, result = _run_locked(motion.move_to, x, y)
    if not ok:
        return jsonify({"ok": False, "error": error}), 409 if error == "Machine is busy" else 400
    return jsonify({"ok": True, "position": result})


@app.route("/api/home", methods=["POST"])
def home():
    ok, error, result = _run_locked(motion.home)
    if not ok:
        return jsonify({"ok": False, "error": error}), 409 if error == "Machine is busy" else 400
    return jsonify({"ok": True, "position": result})


def _draw_smiley_worker():
    try:
        _append_log("Drawing smiley...")
        for x, y in motion.generate_smiley_path():
            motion.move_to(x, y)
            time.sleep(SMILEY_POINT_DELAY_SECONDS)
        _append_log("Smiley complete")
    except motion.MotionError as e:
        _append_log(f"Smiley aborted: {e}")
    finally:
        busy["value"] = False
        motion_lock.release()


@app.route("/api/draw-smiley", methods=["POST"])
def draw_smiley():
    if not motion_lock.acquire(blocking=False):
        return jsonify({"ok": False, "error": "Machine is busy"}), 409
    busy["value"] = True
    threading.Thread(target=_draw_smiley_worker, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/log")
def get_log():
    return jsonify(log[-100:])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
