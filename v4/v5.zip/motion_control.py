"""
Pure motion/geometry logic for the polargraph: one Arduino drives both
stepper motors over a single serial (COM) port, and understands two commands:

    GOTO <left> <right>   -> move both motors' shafts to these absolute
                              step positions, counted from 0 = fully
                              retracted cord (0mm)
    SET  <left> <right>   -> declare the motors are already at these step
                              positions, without moving -- see sync_position()

Only the Pi knows about (x, y) at all. It converts a target position into
each motor's required cord length, then into an absolute step count, and
sends GOTO. Sending absolute targets (not relative deltas) means a single
dropped/garbled command can't compound into drift -- the next GOTO still
names the exact position wanted.

This module has no serial/GPIO code of its own: app.py injects
send_steps(left_steps, right_steps) and send_sync(left_steps, right_steps)
callbacks via configure() that do the actual serial writes. That's what let
this be tested standalone, without a real Pi or Arduino, before ever
touching hardware.
"""

import math

# Matches the web app's default MachineProfile
# (src/core/project/createProject.ts): a 600x800mm drawing area with
# motors at the top-left and top-right corners.
CANVAS_WIDTH_MM = 600
CANVAS_HEIGHT_MM = 800
MOTOR_LEFT = (0.0, 0.0)
MOTOR_RIGHT = (float(CANVAS_WIDTH_MM), 0.0)
HOME_POSITION = (CANVAS_WIDTH_MM / 2, CANVAS_HEIGHT_MM / 2)

# 28BYJ-48 in half-step mode (the 8-step ULN2003 sequence the Arduino
# firmware uses): ~4096 steps per output-shaft revolution (5.625deg stride
# over the ~64:1 gearbox -- the standard cited approximation; the exact
# ratio is 63.68395:1 if more precision is ever needed).
STEPS_PER_REV = 4096

# Cord winds directly around a 20mm-diameter drum (not a belt pulley) --
# circumference = pi * diameter.
DRUM_DIAMETER_MM = 20
DRUM_CIRCUMFERENCE_MM = math.pi * DRUM_DIAMETER_MM

STEPS_PER_MM = STEPS_PER_REV / DRUM_CIRCUMFERENCE_MM  # ~65.19


def _distance(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _clamp(value, low, high):
    return max(low, min(high, value))


class MotionError(Exception):
    pass


class MotorState:
    def __init__(self):
        self.position = HOME_POSITION
        self.left_length_mm = _distance(MOTOR_LEFT, HOME_POSITION)
        self.right_length_mm = _distance(MOTOR_RIGHT, HOME_POSITION)


state = MotorState()
_send_steps_fn = None
_send_sync_fn = None


def configure(send_steps_fn, send_sync_fn=None):
    """send_steps_fn/send_sync_fn(left_absolute_steps: int, right_absolute_steps: int) -> (ok: bool, error: str|None)"""
    global _send_steps_fn, _send_sync_fn
    _send_steps_fn = send_steps_fn
    _send_sync_fn = send_sync_fn


def sync_position():
    """Tells the Arduino "you are already at the Pi's currently-tracked
    position" without moving anything. Call this right after connecting --
    opening a serial port resets most Arduino boards (DTR toggles reset),
    which zeroes its step counters while the Pi still thinks the gondola
    is wherever it last was (usually home, ~500mm of cord out). Without
    this, the next GOTO would travel the *entire* distance from the
    Arduino's false zero instead of the small move actually requested."""
    if _send_sync_fn is None:
        return False, "Motion not configured"
    left_steps = round(state.left_length_mm * STEPS_PER_MM)
    right_steps = round(state.right_length_mm * STEPS_PER_MM)
    return _send_sync_fn(left_steps, right_steps)


def move_to(x, y):
    """The only motion primitive: drive both cords so the gondola reaches
    an absolute (x, y) in mm. Everything else (jog, home, smiley) calls this."""
    if _send_steps_fn is None:
        raise MotionError("Motion not configured")

    x = _clamp(float(x), 0, CANVAS_WIDTH_MM)
    y = _clamp(float(y), 0, CANVAS_HEIGHT_MM)
    target = (x, y)

    target_left_length = _distance(MOTOR_LEFT, target)
    target_right_length = _distance(MOTOR_RIGHT, target)
    left_steps = round(target_left_length * STEPS_PER_MM)
    right_steps = round(target_right_length * STEPS_PER_MM)

    ok, error = _send_steps_fn(left_steps, right_steps)
    if not ok:
        raise MotionError(error)

    state.left_length_mm = target_left_length
    state.right_length_mm = target_right_length
    state.position = target
    return {"x": x, "y": y}


def jog(dx, dy):
    return move_to(state.position[0] + dx, state.position[1] + dy)


def home():
    return move_to(*HOME_POSITION)


# ---------------------------------------------------------------------------
# Smiley face -- fixed test pattern, deliberately simple (big smooth curves,
# generous point spacing) since fine detail is wasted on a machine that
# isn't precise enough for it.
# ---------------------------------------------------------------------------


def _circle_points(cx, cy, r, segments=48):
    return [
        (cx + r * math.cos(2 * math.pi * i / segments), cy + r * math.sin(2 * math.pi * i / segments))
        for i in range(segments + 1)
    ]


def _arc_points(cx, cy, r, start_deg, end_deg, segments=24):
    points = []
    for i in range(segments + 1):
        t = start_deg + (end_deg - start_deg) * i / segments
        rad = math.radians(t)
        points.append((cx + r * math.cos(rad), cy + r * math.sin(rad)))
    return points


def generate_smiley_path():
    """Returns an ordered list of (x, y) mm waypoints: face, left eye, right
    eye, mouth, each connected in sequence (the pen never lifts, so the
    moves between shapes are just more line -- same as everywhere else)."""
    cx, cy = HOME_POSITION
    face = _circle_points(cx, cy, 150)
    left_eye = _circle_points(cx - 60, cy - 50, 15)
    right_eye = _circle_points(cx + 60, cy - 50, 15)
    mouth = _arc_points(cx, cy + 20, 90, 20, 160)  # bottom arc of a circle = a smile, in a y-down space
    return face + left_eye + right_eye + mouth
