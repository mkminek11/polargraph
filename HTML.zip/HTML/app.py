"""
Flask backend for the polargraph controller: manages a serial (COM) connection
to the Arduino and exposes it as a small HTTP API the frontend calls.

Command protocol sent over serial (plain text, newline-terminated). This is
the contract the not-yet-written Arduino firmware should parse:

    HOME                  -> return to home position
    MOVE <x> <y>          -> move to an absolute position, in mm (floats)
    JOG <dx> <dy>         -> move relative to the current position, in mm

Anything the Arduino writes back over serial is captured in a rolling log
(GET /api/log) so the frontend can display it once firmware exists to reply.
"""

import threading
import time

import serial
import serial.tools.list_ports
from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder=".", static_url_path="")

MAX_LOG_LINES = 200
PATH_SEND_DELAY_SECONDS = 0.02  # pacing between queued moves; replace with a real ACK handshake once firmware exists

serial_lock = threading.Lock()
state = {
    "connection": None,
    "port": None,
    "baudrate": 115200,
    "log": [],
}


def _append_log(direction, text):
    state["log"].append({"direction": direction, "text": text, "time": time.time()})
    if len(state["log"]) > MAX_LOG_LINES:
        state["log"] = state["log"][-MAX_LOG_LINES:]


def _reader_loop(ser):
    """Background thread: streams anything the Arduino sends back into the log."""
    while True:
        with serial_lock:
            if state["connection"] is not ser:
                return
        try:
            line = ser.readline()
        except Exception:
            return
        if line:
            text = line.decode("utf-8", errors="replace").strip()
            if text:
                _append_log("recv", text)


def _send_line(line):
    with serial_lock:
        ser = state["connection"]
        if ser is None or not ser.is_open:
            return False, "Not connected"
        try:
            ser.write((line + "\n").encode("utf-8"))
        except Exception as e:
            return False, str(e)
    _append_log("sent", line)
    return True, None


@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/api/ports")
def list_ports():
    ports = serial.tools.list_ports.comports()
    return jsonify([{"device": p.device, "description": p.description} for p in ports])


@app.route("/api/status")
def status():
    with serial_lock:
        connected = state["connection"] is not None and state["connection"].is_open
        return jsonify({"connected": connected, "port": state["port"], "baudrate": state["baudrate"]})


@app.route("/api/connect", methods=["POST"])
def connect():
    data = request.get_json(force=True) or {}
    port = data.get("port")
    baudrate = int(data.get("baudrate", 115200))
    if not port:
        return jsonify({"ok": False, "error": "No port specified"}), 400

    with serial_lock:
        if state["connection"] is not None:
            try:
                state["connection"].close()
            except Exception:
                pass
            state["connection"] = None

        try:
            ser = serial.Serial(port, baudrate, timeout=1)
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

        state["connection"] = ser
        state["port"] = port
        state["baudrate"] = baudrate

    threading.Thread(target=_reader_loop, args=(ser,), daemon=True).start()
    _append_log("system", f"Connected to {port} @ {baudrate}")
    return jsonify({"ok": True})


@app.route("/api/disconnect", methods=["POST"])
def disconnect():
    with serial_lock:
        if state["connection"] is not None:
            try:
                state["connection"].close()
            except Exception:
                pass
            state["connection"] = None
            state["port"] = None
    _append_log("system", "Disconnected")
    return jsonify({"ok": True})


@app.route("/api/command", methods=["POST"])
def send_command():
    data = request.get_json(force=True) or {}
    line = (data.get("command") or "").strip()
    if not line:
        return jsonify({"ok": False, "error": "Empty command"}), 400
    ok, error = _send_line(line)
    if not ok:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True})


@app.route("/api/move", methods=["POST"])
def move():
    data = request.get_json(force=True) or {}
    x, y = data.get("x"), data.get("y")
    if x is None or y is None:
        return jsonify({"ok": False, "error": "x and y required"}), 400
    ok, error = _send_line(f"MOVE {float(x):.2f} {float(y):.2f}")
    if not ok:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True})


@app.route("/api/jog", methods=["POST"])
def jog():
    data = request.get_json(force=True) or {}
    dx, dy = data.get("dx", 0), data.get("dy", 0)
    ok, error = _send_line(f"JOG {float(dx):.2f} {float(dy):.2f}")
    if not ok:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True})


@app.route("/api/home", methods=["POST"])
def home():
    ok, error = _send_line("HOME")
    if not ok:
        return jsonify({"ok": False, "error": error}), 400
    return jsonify({"ok": True})


@app.route("/api/path", methods=["POST"])
def send_path():
    """Sends a whole drawing as a queued sequence of MOVE commands."""
    data = request.get_json(force=True) or {}
    points = data.get("points", [])
    if not isinstance(points, list) or not points:
        return jsonify({"ok": False, "error": "points required"}), 400

    sent = 0
    for p in points:
        x, y = p.get("x"), p.get("y")
        if x is None or y is None:
            continue
        ok, error = _send_line(f"MOVE {float(x):.2f} {float(y):.2f}")
        if not ok:
            return jsonify({"ok": False, "error": error, "sent": sent}), 400
        sent += 1
        time.sleep(PATH_SEND_DELAY_SECONDS)

    return jsonify({"ok": True, "sent": sent})


@app.route("/api/log")
def get_log():
    with serial_lock:
        return jsonify(state["log"][-100:])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
